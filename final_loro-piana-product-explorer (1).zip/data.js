
// Image dimensions and positions are calculated dynamically in ImageGrid.jsx
// This file serves as the single source of truth for product data.

export const mockImageData = [
  {
    id: 'FAP6890_T1N4',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP6890/73B345F2-C2BC-477F-ACD0-5122A95624BA/FAP6890_T1N4_SMALL.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Sesia Bag',
    name: 'Sesia Bag Pink',
    price: '€2,450.00',
    tags: { color: 'Powder Pink', texture: 'Calfskin', type: 'Handbag' },
  },
  {
    id: 'FAP1571_F6V8',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP1571/BF10B1C3-208B-4717-818E-C31E9469D728/FAP1571_F6V8_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Leather Tote',
    name: 'Spagna Leather Tote',
    price: '€3,200.00',
    tags: { color: 'Tan', texture: 'Leather', type: 'Tote Bag' },
  },
  {
    id: 'FAP4505_R190',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP4505/28ADDF46-B0FA-480E-8B6F-78A7EFF38245/FAP4505_R190_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Suede Jacket',
    name: 'Roadster Suede Jacket',
    price: '€4,800.00',
    tags: { color: 'Burgundy', texture: 'Suede', type: 'Outerwear' },
  },
  {
    id: 'FAP5278_F6XA',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP5278/FA5C1BAD-C61F-4D7A-A20D-F28E1A841D48/FAP5278_F6XA_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Cashmere Scarf',
    name: 'Extra Bag L27',
    price: '€2,500.00',
    tags: { color: 'Sky Blue', texture: 'Cashmere', type: 'Accessory' },
  },
  {
    id: 'FAO8041_F7A7',
    src: 'https://media.loropiana.com/HYBRIS/FAO/FAO8041/6EAEEA9E-3E4D-4029-858D-E40840D27097/FAO8041_F7A7_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Silk Shirt',
    name: 'André Silk Shirt',
    price: '€1,150.00',
    tags: { color: 'Ivory', texture: 'Silk', type: 'Top' },
  },
  {
    id: 'FAO0185_B4AU',
    src: 'https://media.loropiana.com/HYBRIS/FAO/FAO0185/7DDD8651-D5E2-421F-A596-BCB88FDE53A7/FAO0185_B4AU_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Linen Trousers',
    name: 'Mathias Linen Trousers',
    price: '€890.00',
    tags: { color: 'Beige', texture: 'Linen', type: 'Bottoms' },
  },
  {
    id: 'FAP9039_T1RS',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP9039/098E9740-FD33-4174-B185-E7C2ABCF2632/FAP9039_T1RS_SMALL.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Small Clutch',
    name: 'Extra Pocket L12 Clutch',
    price: '€1,300.00',
    tags: { color: 'Rose Quartz', texture: 'Ostrich Leather', type: 'Clutch' },
  },
  {
    id: 'FAP4739_R0E2',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP4739/3A5725DC-C9D8-4CE7-9A11-F5D99B593B32/FAP4739_R0E2_SMALL.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Woven Belt',
    name: 'Pacific Woven Belt',
    price: '€520.00',
    tags: { color: 'Multi-Brown', texture: 'Leather', type: 'Accessory' },
  },
  {
    id: 'FAP2569_T1N8',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP2569/4A58C083-0035-48A2-B354-80297E7372C1/FAP2569_T1N8_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Cashmere Coat',
    name: 'Martingala Cashmere Coat',
    price: '€5,500.00',
    tags: { color: 'Dark Navy', texture: 'Cashmere', type: 'Outerwear' },
  },
  {
    id: 'FAO9704_20GI',
    src: 'https://media.loropiana.com/HYBRIS/FAO/FAO9704/461F3132-DCCD-4F23-A484-A48B2019B911/FAO9704_20GI_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Suede Loafers',
    name: 'Summer Charms Walk Loafers',
    price: '€910.00',
    tags: { color: 'Ice Grey', texture: 'Suede', type: 'Footwear' },
  },
  {
    id: 'FAP0271_T1N4',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP0271/97F78F41-3F80-467E-B357-8076C0C585E7/FAP0271_T1N4_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Pouch',
    name: 'Sesia Pouch',
    price: '€1,050.00',
    tags: { color: 'Rose', texture: 'Calfskin', type: 'Accessory' },
  },
  {
    id: 'FAP5226_20DS',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP5226/A1BE2AEE-A86A-491F-B23D-9905E73D83DE/FAP5226_20DS_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - White Sneakers',
    name: '360 Flexy Walk Sneaker',
    price: '€780.00',
    tags: { color: 'White', texture: 'Wish® Wool', type: 'Footwear' },
  },
  {
    id: 'FAP4708_B577',
    src: 'https://media.loropiana.com/HYBRIS/FAP/FAP4708/CF0BD6B6-9735-445A-B6B1-76BC0E97F257/FAP4708_B577_MEDIUM.jpg?sw=300&sh=400',
    alt: 'Loro Piana Product Image - Knit Sweater',
    name: 'Girocollo Cashmere Sweater',
    price: '€1,250.00',
    tags: { color: 'Turquoise', texture: 'Cashmere', type: 'Knitwear' },
  }
];

// Special list for "Extra Bag L27" similarity
const extraBagSimilarImages = [
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAP5283_B5CE_SMALL.jpg",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2126_20ES_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2126_D0Q7_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2126_P0AI_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2141_B5KB_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2180_804L_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2180_D0QB_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2180_E0DA_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2326_804L_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2800_B5NO_SMALL.avif",
  "https://raw.githubusercontent.com/marcelorm81/lpgrid2/557157293a47fc21f39a4acb59dc3f7da0bb73f3/FAQ2841_B5NA_SMALL.avif"
];

export const extraBagProducts = extraBagSimilarImages.map((src, index) => ({
  id: `extra-sim-${index}`,
  src,
  name: 'Extra Bag Variant',
  price: '€2,500.00',
  alt: 'Extra Bag Variant',
  tags: { color: 'Multi', texture: 'Leather', type: 'Bag' }
}));
